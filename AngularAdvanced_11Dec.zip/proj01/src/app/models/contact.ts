export interface Contact {
    id:number;
    fullName:string;
    mobile:string;
    mailId:string;    
}
