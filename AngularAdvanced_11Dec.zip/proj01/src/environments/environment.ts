export const environment = {
    apptitle:"Address Book"
};
