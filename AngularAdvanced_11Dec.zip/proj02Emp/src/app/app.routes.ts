import { Routes } from '@angular/router';

export const routes: Routes = [
    {path:'', pathMatch:'full', redirectTo:'/employees'},
    {path:'employees', 
        loadComponent: () => import('./employee/employee-list/employee-list.component').then(m => m.EmployeeListComponent)}
];
