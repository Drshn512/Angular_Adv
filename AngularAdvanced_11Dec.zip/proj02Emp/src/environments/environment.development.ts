export const environment = {
    apptitle: 'Employees [dev]'
};
