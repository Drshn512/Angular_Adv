import { Routes } from '@angular/router';

export const routes: Routes = [
    {path:'', pathMatch:'full', redirectTo:'/employees'},
    {path:'employees', 
        loadComponent: () => import('./employee/employee-list/employee-list.component').then(m => m.EmployeeListComponent)},
    {path:'addEmployee', 
        loadComponent: () => import('./employee/employee-form/employee-form.component').then(m => m.EmployeeFormComponent)},
    {path:'updateEmployee/:id', 
        loadComponent: () => import('./employee/employee-form/employee-form.component').then(m => m.EmployeeFormComponent)}
];
