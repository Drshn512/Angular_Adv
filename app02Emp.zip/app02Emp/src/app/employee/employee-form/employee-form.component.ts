import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { EmployeeService } from '../../services/employee.service';

@Component({
  selector: 'app-employee-form',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './employee-form.component.html',
  styleUrl: './employee-form.component.css'
})
export class EmployeeFormComponent {
  employeeForm: FormGroup;

  constructor(private employeeService: EmployeeService,private formBuilder: FormBuilder){
    this.employeeForm = formBuilder.group({
      id: [0],
      name: ['', [Validators.required]],
      empId: [0, [Validators.required]],
      mail: ['', [Validators.required, Validators.email]]
    })
  }

  get name(){
    return this.employeeForm.get('name');
  }
  get empId(){
    return this.employeeForm.get('empId');
  }
  get mail(){
    return this.employeeForm.get('mail');
  }

  submitForm(){
    this.employeeService.addEmployee(this.employeeForm.value);
    this.employeeForm.reset({id: 0, name: '', empId: 0, mail: ''});
  }
}
