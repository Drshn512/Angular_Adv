export interface Link{
    label: string,
    target: string
}