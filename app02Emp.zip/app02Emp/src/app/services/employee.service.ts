import { computed, Injectable, Signal, signal, WritableSignal } from '@angular/core';
import { Employee } from '../models/employee';
import { MessageBoxService } from './message-box.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employees: WritableSignal<Employee[]> = signal<Employee[]>([]);

  isEmployeesEmpty: Signal<boolean> = computed<boolean>(() => !this.employees || this.employees().length === 0);
  private nextid: number;

  constructor(private ms: MessageBoxService) { 
    this.employees.set([
      {id: 1, name: 'Darshan Patel', empId: 2235119, mail: '2235119@cognizant.com'},
      {id: 2, name: 'Navneet Rathore', empId: 2235120, mail: '2235120@cognizant.com'},
      {id: 3, name: 'Gaurav Rajput', empId: 2235121, mail: '2235121@cognizant.com'},
      {id: 4, name: 'Ashlesh Ghore', empId: 2235122, mail: '2235122@cognizant.com'},
    ])
    this.nextid = 5;
  }

  addEmployee(employee: Employee){
    employee.id = this.nextid++;
    this.employees.update( list => [...list, employee]);
    this.ms.add(`Employee added with an emp id: ${employee.empId}`);
  }
  
  deleteById(id: number){
    this.employees.update(list => list.filter(e => e.id !== id));
    this.ms.add(`Employee deleted with an emp id: ${id}`);
  }
  
  updateEmployee(employee: Employee){
    this.employees.update(list => list.map(e => e.id !== employee.id ? e: employee));
    this.ms.add(`Employee updated with an id: ${employee.empId}`);
  }
}
