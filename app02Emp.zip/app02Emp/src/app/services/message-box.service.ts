import { Injectable, signal, WritableSignal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MessageBoxService {

  messages: WritableSignal<string[]>;

  constructor() {
    this.messages = signal([]);
  }

  clear(){
    this.messages.set([]);
  }

  add(message: string){
    this.messages.update(mesgs => [...mesgs, message]);
  }

  delete(message: string){
    this.messages.update(msgs => msgs.filter(m => m!=message));
  }
}
