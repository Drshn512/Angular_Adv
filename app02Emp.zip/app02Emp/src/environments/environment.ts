export const environment = {
    apptitle: 'Employees'
};
